import MainMenu
import GameLoop
import Player


class Controller:

    def __init__(self):
        self.GAME_STATE = "MENU"

        self.GAME_STATES = {
            "MENU": self.state_GAME_MENU,
            "RUNNING": self.state_RUNNING,
            "QUIT": self.state_QUIT
        }
        self.menu = MainMenu.MainMenu()

    def set_GAME_STATE(self, game_state):
        self.GAME_STATE = game_state

    def get_GAME_STATE(self):
        return self.GAME_STATE

    def state_GAME_MENU(self):
        new_state = self.menu.state_GAME_MENU()
        return new_state

    """ENTER GAME LOOP HERE"""

    def state_RUNNING(self):
        title = self.menu.player_attributes[1]
        first_name = self.menu.player_attributes[2]
        last_name = self.menu.player_attributes[3]
        pet_type = self.menu.player_attributes[4]
        pet_name = self.menu.player_attributes[5]
        player_attributes = {
                            1: title,
                            2: first_name,
                            3: last_name,
                            4: pet_type,
                            5: pet_name
                            }

        player = Player.Player(player_attributes)
        game = GameLoop.GameLoop(player)

        return game.game_loop()

    def state_QUIT(self):
        # debugging print state to follow control flow on shutdown
        print("QUITTING GAME")
        return "QUIT"
