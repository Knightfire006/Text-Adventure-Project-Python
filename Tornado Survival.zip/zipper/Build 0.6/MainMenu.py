import NewGameMenu


class MainMenu():

    def __init__(self):
        self.MENU_STATES = {
            "NEW GAME": self.NEW_GAME_STATE,
            "QUIT": self.state_QUIT,
            "ADMIN": self.state_ADMIN
        }

        self.player_attributes = {}
        self.ADMIN_MODE = False

    def NEW_GAME_STATE(self):
        new_game = NewGameMenu.NewGameMenu()
        if new_game.main_menu():
            self.player_attributes = new_game.player_attributes
            return "RUNNING"
        else:
            return "MENU"

    def get_player_attribute(self, index):
        if index in self.player_attributes:
            return self.player_attributes[index]()

    # Main Menu State
    def state_GAME_MENU(self):
        self.get_Menu()
        state_menu = self.set_MENU_STATE(self.set_input(3))
        for key, value in self.MENU_STATES.items():
            if state_menu == key:
                return value()

    # prints menu
    def get_Menu(self):
        print("\n\n\n\nEscape Room Challenge")
        print("Main Menu")
        print("1: New Game")
        print("2: Quit")
        print("\n\nWhat would you like to do?\nPlease type the number of your choice: ")

    # keeps the main menu simple with integer inputs instead of typing. could easily be for loop like other STATEs
    def set_MENU_STATE(self, value):
        if value == 1:
            return "NEW GAME"
        elif value == 2:
            return "QUIT"
        # admin run to bypass character creation
        elif value == 3:
            return "ADMIN"
        else:
            print("Invalid STATE. Location in Menu State")

    # test integer inputs
    def set_input(self, max_num):
        is_valid = False
        while not is_valid:
            try:
                player_input = int(input())
                if max_num >= player_input > 0:
                    is_valid = True
            except ValueError:
                print("Invalid entry! Please enter a Valid entry!")
        return player_input

    # DEV CHEAT to bypass character creation and jump to gameloop
    def state_ADMIN(self):
        self.player_attributes = {
            1: " ",
            2: "AI",
            3: "Cortana",
            4: "Cat",
            5: "Micah"
        }
        self.ADMIN_MODE = True
        print("By passed character Creation.")
        return "RUNNING"

    def state_QUIT(self):
        return "QUIT"
