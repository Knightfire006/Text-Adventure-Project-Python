# not implemented

class GameObject:
    def __init__(self, name, obj_type="STATIC", require=None):
        self.object_name = name # a water bottle
        self.object_type = obj_type # static
        self.requirements = require # no key required




# static objects: freely able to interact
water_bottle = GameObject("A WATER BOTTLE")
tba = GameObject("TBA")
small_key = GameObject("SMALL KEY", "KEY")

# gated items: require keys to access
antidote = GameObject("ANTIDOTE", "GATED")
door_key = GameObject("DOOR KEY", "GATED")

# barriers that require keys
keypad = GameObject("KEYPAD", "BARRIER", "PASSWORD")
safe = GameObject("SAFE", "BARRIER", "SMALL KEY")
door_office = GameObject("OFFICE DOOR", "BARRIER", "DOOR KEY")






