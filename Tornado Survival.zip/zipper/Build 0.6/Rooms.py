from random import *
from datetime import datetime


class Rooms:
    def __init__(self,
                 room_name="MASTER", state_name="MASTER",
                 room_item_type="ITEM", item="NO ITEM",
                 key=None, reward=None,
                 dirNorth=False, dirSouth=False, dirEast=False, dirWest=False,
                 item_flag=True
                 ):

        self.name = room_name
        self.STATE_NAME = state_name
        self.item_type = room_item_type
        self.item_name = item
        self.roomItem = {"COLLECT":
            {self.item_type: self.item_name}}
        self.roomItem_has_item = item_flag
        # stores roomItem so it can be placed behind a lock
        # setting it equal to self.roomItem causes it be overriden later
        self.unlocked_item = {"COLLECT":
            {self.item_type: self.item_name}}

        self.direction_north = dirNorth
        self.direction_south = dirSouth
        self.direction_east = dirEast
        self.direction_west = dirWest

        self.directionList = {"GO": {
            "NORTH": self.direction_north,
            "SOUTH": self.direction_south,
            "EAST": self.direction_east,
            "WEST": self.direction_west}}

        self.key_required = key
        self.locked_barrier = None
        self.reward_item = reward


    def _get_name(self):
        return self.name

    def _get_STATE_NAME(self):
        return self.STATE_NAME

    def _get_roomItem(self):
        return self.roomItem

    def _get_roomItem_has_item(self):
        return self.roomItem_has_item

    def _get_directionList(self):
        return self.directionList

    def _update_roomItem(self):
        self.roomItem["ITEM"] = "NO ITEM"
        self.roomItem_has_item = False

    def _update_lock_status(self):
        self.roomItem = self.reward_item

    def create_password(self):
        self.password = []
        seed(datetime.now().timestamp())
        for nums in range(3):
            value = randint(0, 100)
            self.password.append(value)

    def _get_password(self):
        return self.password

    def _print_password(self):
        for nums in self.password:
            print(nums, end=" ")
        print()

    def _set_item_locks(self, item_name, key_required):
        self.key_required = key_required
        self.locked_barrier = item_name
        # overrides room item with lock
        self.roomItem = {"INTERACT": {self.locked_barrier: "LOCKED"}}

    def open_lock(self, player):
        if self.key_required in player.inventory:
            print("You unlocked the {}".format(self.locked_barrier))
            self.roomItem = self.unlocked_item
        else:
            print("The {} is locked! Search the house to find something to unlock it".format(self.locked_barrier))
        return self.roomItem

    def _set_door_locks(self, door_name, key_reqired, door_direction):
        self.locked_barrier = door_name # name of lock
        self.key_required = key_reqired # key required to unlock lock
        self.locked_door = door_direction # key direction of the door
        self.locked_item = self.directionList["GO"][door_direction] # saves original door to be unlocked
        self.directionList["GO"][door_direction] = None # sets the direction to None while locked
        self.roomItem = {"UNLOCK": {self.locked_barrier: self.locked_door}} # creates interface to unlock door


    def open_door(self, player):
        if self.key_required == player.password:
            print("You unlocked the {}".format(self.locked_barrier))
            self.directionList["GO"][self.locked_door] = self.locked_item
            self._update_roomItem()

        else:
            print("This {} is locked! Quick, find someting to unlock it!".format(self.locked_barrier))

        return self.roomItem