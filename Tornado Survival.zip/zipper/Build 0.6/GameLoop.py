import RoomManager
import Dialogue


narrator = Dialogue.Dialogue("Orator")
# CONST VARS
TORNADO_COUNTDOWN = 12

class GameLoop:

    def __init__(self, player):
        self.room_state = "OPENING"
        self.player = player

    def _set_room_state(self, state):
        self.room_state = state

    def _get_room_state(self):
        return self.room_state

    def opening_state(self, player_first_name="Jane", player_last_name="Doe"):
        opening = True
        while opening:
            opening = narrator.opening_diaglogue(player_first_name, player_last_name)
        return "OFFICE"

    def game_over_state(self):
        print("GAME OVER!")
        if self.player.check_player_inventory():
            print("You Win!")
        else:
            print("You DIED!")

    ##GAME LOOP
    def game_loop(self):

        turn = 0
        self._set_room_state(self.opening_state(self.player.first_name, self.player.last_name))

        room_manager = RoomManager.RoomManager(self.player.random_item1, self.player.random_item2)

        room_manager._get_help()
        while "SAFE ROOM" != self._get_room_state() != "GAME OVER":

            current_state = self._get_room_state()

            for room in room_manager.room_dict:
                if current_state == room.STATE_NAME:
                    self._set_room_state(room_manager.room_interface(self.player, room))

            if not self.player._get_antidote_status() and turn > 0:
                self.player._update_health()

                if self.player._get_health() == 0:
                    print(
                        "Your vision states to fade. Your legs feel weak and the begins to spin. You go to scream out for help but the words beckon. You fallen over to the ground and everything turns black!")
                    self._set_room_state("GAME OVER")

            turn += 1
            if turn == TORNADO_COUNTDOWN:
                print("THE TORNADO HITS YOUR HOUSE AND SUCKS YOU UP!")
                self._set_room_state("GAME OVER")

        self.game_over_state()
        print("Would you like to play again?")
        input("Hit the ENTER key to continue to MAIN MENU")

        return "MENU"

        

        

