
class Dialogue():

    def __init__(self, name= "Narrator"):
        self.name = name


    def set_input(self, max):
        is_valid = False
        while not is_valid:
            try:
                player_input = int(input())
                if player_input > 0 and player_input <= max:
                    is_valid = True
            except:
                print("Invalid entry! Please enter a Valid entry!")
        return player_input


    def opening_diaglogue(self, first_name, last_name):
        print("{} {} OPENING SCENE GOES HERE".format(first_name, last_name))
