"""
Class is the Character Creation menu part of the Main Menu of the game
"""

class NewGameMenu:
    def __init__(self):
        # default values
        self.title = ""
        self.first_name = ""
        self.last_name = ""
        self.petType = ""
        self.pet = ""

        # dictionary hold the states for the Character Creation.
        self.menu_states = {
            0: self.main_menu,
            1: self.set_player_title,
            2: self.set_player_first_name,
            3: self.set_player_last_name,
            4: self.pick_a_pet,
            5: self.create_pet_name,
            6: self.get_character_information
        }
        # used to pass player attributes to other classes
        self.player_attributes = {}

        # pet types
        self.pet_types = {
            1: "Cat",
            2: "Dog",
        }


    # sets the player's title
    def set_player_title(self):
        self.title = input("\nEnter your title, EX: Mr. Mrs. Commander....: ")
        self.player_attributes.update({1: self.title})
        return self.title


    # sets the player's first name
    def set_player_first_name(self):
        self.first_name = input("\nEneter your characters first name: ")
        self.player_attributes.update(({2: self.first_name}))
        return self.first_name


    # sets the player's last name
    def set_player_last_name(self):
        self.last_name = input("\nEnter your character's last name: ")
        self.player_attributes.update({3: self.last_name})
        return self.last_name


    # sets the player's pet
    # while loop serves a check to make sure the player inputs a valid input
    def pick_a_pet(self):
        valid = None
        while not valid:

            self._get_pet_types()
            selection = input("Enter the number selection for you pet: ")
            if selection.upper() == "MENU" or selection.upper() == "BACK":
                self.petType = selection
                valid = True
            else:
                try:
                    selection = int(selection)

                    if selection in self.pet_types:
                        valid = True
                        self.petType = self.pet_types[selection]
                    else:
                        valid = False

                except ValueError:
                    print("Invalid selection! Please Type an integer")
        self.player_attributes.update({4: self.petType})
        return self.petType


    # create the pet name for the player
    def create_pet_name(self):
        self.pet = input("Enter a name for you pet {}: ".format(self.petType))
        self.player_attributes.update({5: self.pet})
        return self.pet


    # returns the pet type
    def _get_pet_types(self):
        for key, value in self.pet_types.items():
            print(key, ":", value, end=" ")
        print()


    # checks user inputs
    def check_input(self, user_input):
        test = user_input
        if test.upper() == "MENU":
            return -100
        if test.upper() == "BACK":
            return -1
        else:
            return 1


    # prints the players attributes
    def get_character_information(self):
        index = 1
        for key, value in self.player_attributes.items():
            if key == index:
                print("{}: {}".format(key, value))
                index += 1
        return "Pass"


    # the main menu 0f the character creation
    # uses numbers to iterate through the character creation states
    def main_menu(self):
        creation = False
        current_state = 1
        while current_state > 0:

            if current_state > len(self.menu_states) - 1:
                current_state = 0
                creation = True

            else:
                print("Main Menu")
                print("Type: 'BACK' to go back to previous selection. Type 'MENU' to return to Main Menu")

                if current_state in self.menu_states:
                    new_state = self.menu_states[current_state]()
                    current_state += self.check_input(new_state)      

        return creation
