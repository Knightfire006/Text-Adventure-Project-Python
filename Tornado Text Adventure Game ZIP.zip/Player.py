"""
Class to hold all the player attributes and functions that directly affect the player.
"""

class Player:
    #constant global vars
    # max player health
    MAX_HEALTH = 100
    # max inventory size
    FULL_INVENTORY = 6
    # damage received per turn from injury
    DAMAGE = 5
    # default variables for player. used for debugging if player creation and admin fails.
    DEFAULT_ATTS = {
        1: "Master Chief Petty Officer",
        2: "John",
        3: "117",
        4: "AI",
        5: "CORTANA"
    }
    # class init
    def __init__(self, player_attributes=DEFAULT_ATTS):
        self.health = self.MAX_HEALTH
        starting_health = self.MAX_HEALTH - 50
        self.health = starting_health
        self.title = player_attributes[1]
        self.first_name = player_attributes[2]
        self.last_name = player_attributes[3]
        self.pet_type = player_attributes[4]
        self.pet_name = player_attributes[5]
        self.inventory = []
        self.full_inventory = self.FULL_INVENTORY
        self.password = []

        # pet type affects the player item in game and locations for pet item and pet.
        if self.pet_type == "Dog":
            self.random_item1 = self.pet_name
            self.random_item2 = "LEASH"

        elif self.pet_type == "Cat":
            self.random_item1 = "CARRIER"
            self.random_item2 = self.pet_name


    # sets player first name
    def _set_first_name(self, first_name):
        self.first_name = first_name


    # sets player last name
    def _set_last_name(self, last_name):
        self.last_name = last_name


    # returns the global inventory max size
    def _get_full_inventory_size(self):
        return self.full_inventory


    # returns player first name
    def _get_first_name(self):
        return self.first_name


    # returns player last name
    def _get_last_name(self):
        return self.last_name


    # returns player health
    def _get_health(self):
        return self.health

    # returns the medical status of player
    def _get_medical_status(self):
        if "FIRST AID KIT" in self.inventory:
            return True
        else:
            return False


    # if player does not have the First Aid Kit then health is subtracted
    def _update_health(self):
        self.health -= self.DAMAGE
        if self._get_health() > 0:
            print("{} You are injured! HEALTH drained To {}! Quickly Find a FIRST AID KIT!".format(self._get_first_name(), self._get_health()))


    # updates the player inventory with the password found in safe
    def _update_password(self, listofnums):
        # print(listofnums) fixme remove?
        for nums in listofnums:
            # print(nums, end=" ")
            self.password.append(nums)


    # handles all inventory management with adding items and notifying player of picking up the items
    def _update_inventory(self, item):
        self.inventory.append(item)
        print("\n\nyou have collected {}\n".format(item))

        if item == "FIRST AID KIT":
            self.health += 50
            print("You use the FIRST AID KIT and stop the bleeding!")

        elif item == self.random_item1 or item == self.random_item2:
            if self.random_item2 in self.inventory and self.random_item1 in self.inventory:
                if self.pet_type == "Dog":
                    print("You quickly put {} on the {}".format(self.pet_name, self.random_item2))

                else:
                    print("You quickly pick up {} and put them in the {}".format(self.pet_name, self.random_item1))

            elif item == self.pet_name and self.pet_type == "Dog":
                print("You call to {} to follow you! They bark and run over to you! Now to find their {}!".format(self.pet_name, self.random_item2))

            elif item == self.pet_name and self.pet_type == "Cat":
                print("You run over and pick up {}! They let out a loud meow and dig their claws into you! Now to find their {}!".format(self.pet_name, self.random_item1))

            elif self.pet_type == "Dog":
                print("You grab the {}. Now to find {}!".format(self.random_item2,self.pet_name))

            else:
                print("You grab the cat {}. Now to find {}!".format(self.random_item1, self.pet_name))


    # Players Heads up display. Prints name, health, and inventory
    def _get_player_status(self):
        print(self._get_first_name(), self._get_last_name(), "Health:", self._get_health())
        print("INVENTORY: ")
        for key in self.inventory:
            if key == "PASSWORD":
                print("'{}: {}'".format(key, self.password), end=(" "))
            else:
                print(" '{}' ".format(key), end=(" "))
        print()


    # checks to see if the player has a full inventory. used to determine if player collected all items at end of game
    def check_player_inventory(self):
        if len(self.inventory) == self.full_inventory:
            return True
        else:
            return False

