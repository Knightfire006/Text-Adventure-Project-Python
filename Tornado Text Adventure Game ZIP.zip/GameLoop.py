import RoomManager
import Dialogue
"""
Class handles the state of the game including win/lose condition
"""

narrator = Dialogue.Dialogue("Orator")
# CONST VARS
TORNADO_COUNTDOWN = 12

class GameLoop:
    # sets player attributes passed to game loop and sets the room state the opening scene
    def __init__(self, player):
        self.room_state = "OPENING"
        self.player = player


    # sets the room state
    def _set_room_state(self, state):
        self.room_state = state


    # gets the room state
    def _get_room_state(self):
        return self.room_state


    # opening state that plays opening scene then sets the starting room to Office
    def opening_state(self, player_first_name="Jane", player_last_name="Doe"):
        opening = True
        while opening:
            opening = narrator.opening_diaglogue(player_first_name, player_last_name)
        return "OFFICE"


    # Game over state that checks the player's inventory to see if the player wins
    def game_over_state(self):
        print("GAME OVER!")
        if self.player.check_player_inventory() and self.room_state == "SAFE ROOM":
            print("You Win!")
        else:
            print("You DIED!")


    # GAME LOOP
    def game_loop(self):
        # keeps track of how many times the player moves between rooms. turn only increments when the player moves
        # between rooms. Interacting with objects does NOT increment the turn counter
        turn = 0

        # sets the room to the opening state
        self._set_room_state(self.opening_state(self.player.first_name, self.player.last_name))

        # creates the game board
        room_manager = RoomManager.RoomManager(self.player.random_item1, self.player.random_item2)

        # prints the tutorial at start of game
        room_manager._get_help()


        # while the player is not in the safe room, has not quit, nor hit by the tornado, the game loop continues
        while "SAFE ROOM" != self._get_room_state() != "GAME OVER":

            # checks for current state
            current_state = self._get_room_state()

            # takes current room state and interfaces with it
            for room in room_manager.room_dict:
                if current_state == room.STATE_NAME:
                    self._set_room_state(room_manager.room_interface(self.player, room))

            # between each move command the player loses health if they have not collected the First Aid Kit
            if not self.player._get_medical_status() and turn > 0:
                self.player._update_health()

                # if the player's health reaches 0, the player dies and the game state is set to game over.
                if self.player._get_health() == 0:
                    print(
                        "Your vision states to fade. Your legs feel weak and the begins to spin. You go to scream out for help but the words beckon. You fallen over to the ground and everything turns black!")
                    self._set_room_state("GAME OVER")

            # each time the player moves between the room, the tornado counter ticks down. Once it reaches 0 and the player
            # is not in the safe room with all items, the player is defeated.
            turn += 1
            if turn == TORNADO_COUNTDOWN:
                print("THE TORNADO HITS YOUR HOUSE AND SUCKS YOU UP!")
                self._set_room_state("GAME OVER")

        # once the while loop is over, the player is offered to play the game again and the game returns to the main menu
        self.game_over_state()
        print("Would you like to play again?")
        input("Hit the ENTER key to continue to MAIN MENU")

        return "MENU"

        

        

