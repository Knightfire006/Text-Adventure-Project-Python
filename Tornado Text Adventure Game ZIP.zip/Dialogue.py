
class Dialogue():

    def __init__(self, name= "Narrator"):
        self.name = name


    def opening_diaglogue(self, first_name, last_name):
        print("\n\n\n\n\n\n")
        print("{} {}: You are in your office working on homework on the computer.".format(first_name, last_name))
        print("Thunder roars in the distance and shakes the house.")
        print("You decide to get up and look outside the window to look at the approaching storm.")
        print("As you gaze outside the window you see an ominous black cloud approaching your house quickly.")
        print("The wind starts to pick up and the rain begins the pour.")
        print("Suddenly a large object smashes up against your window, showering you with glass.")
        print("Disoriented, you fall to the ground. You Touch your face and head and feel a warm liquid.")
        print("You are bleeding!")
        print("You know the Bathroom has a First Aid Kit to help stop the bleeding!")
        print("As you stand up, you hear what could be described as a freight train speeding towards you.")
        print("Outside the window you see a large cyclone swirling towards your house!")
        print("QUICK! GET TO THE SAFE ROOM!")
        print("OBJECTIVE: Find the necessary items to stop the bleeding, rescue your pet and access the Safe Room!")