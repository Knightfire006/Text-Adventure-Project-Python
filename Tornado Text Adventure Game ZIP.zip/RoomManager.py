from Rooms import *
"""
Class that creates room objects, handles player movement between rooms and player inputs
"""

class RoomManager:
    def __init__(self, random_item1, random_item2):
        # random items 1 & 2 are either pet or pet restraining devise(cat carrier or dog leash)
        self.random_item1 = random_item1
        self.random_item2 = random_item2

        # creation of rooms
        office = Rooms("office", state_name= "OFFICE", dirEast= "KITCHEN", item_flag=False)
        kitchen = Rooms("Kitchen", state_name= "KITCHEN", item="FOOD and WATER", dirWest= "OFFICE", dirSouth= "DINING ROOM", dirEast= "GARAGE")
        dining_room = Rooms("Dining Room", state_name="DINING ROOM", item= self.random_item2, dirEast= "LIVING ROOM", dirWest= "BED ROOM", dirNorth= "KITCHEN", dirSouth= "OUTSIDE")
        living_room = Rooms("Living Room", state_name="LIVING ROOM", item="SMALL KEY", dirWest= "DINING ROOM", dirNorth= "GARAGE")
        garage = Rooms("Garage", state_name= "GARAGE" ,item= self.random_item1, dirWest= "KITCHEN", dirSouth= "LIVING ROOM")
        bed_room = Rooms("Bed Room", state_name= "BED ROOM" ,item= "PASSWORD", dirEast= "DINING ROOM", dirSouth= "BATHROOM")
        bathroom = Rooms("Bathroom", state_name="BATHROOM", item= "FIRST AID KIT", dirNorth= "BED ROOM")
        outside = Rooms("Outside", state_name= "OUTSIDE",item="KEYPAD", dirNorth="DINING ROOM", dirSouth="SAFE ROOM")

        # room unique statues
        # creates Safe item in bed rooom that require small to enter and rewards the password for the safe room
        bed_room.create_password()
        bed_room._set_item_locks("SAFE", "SMALL KEY")
        # uses the password created inside the safe for the safe house, links to keypad, and ties it do direction south
        outside.password = bed_room.password
        outside._set_door_locks("KEYPAD", outside.password, "SOUTH")

        # list of all rooms
        self.room_dict = [office, kitchen, dining_room, living_room, garage, bed_room, bathroom, outside]

        # place holder for reference guide.
        self.current_command_action = None
        self.current_command_noun = None
        self.current_command_pair = None
        self.current_room = None
        self.current_room_status = None
        self.roomItem = None
        self.directionList = None

        # game tutorial
        self.help_list = {"HELP": {
            "TUTORIAL": "Type in the command prompt to play the game. Collect all items and exit to win",
            "COMMANDS make up two words": "ACTION and a NOUN",
            "To move between rooms, type 'GO' then the compass direction. EX": "GO SOUTH",
            "To interact with objects type the correct action like 'COLLECT' then the NOUN. EX": "COLLECT ITEM",
            "Type HELP to reprint these instructions!": "HAVE FUN!"}}

        # hold the rooms possible interactions. varies per room
        self.room_options = {}
        # variable that allows the player to quit at anytime
        self.QUIT = False

    # generates the rooms possible interactions
    def _update_current_room_status(self, room):
        # room object
        self.current_room_status = room
        # room's item
        self.roomItem = room._get_roomItem()
        # rooms exit directions
        self.directionList = room._get_directionList()
        # room item status
        self.roomItem_has_item = room._get_roomItem_has_item()
        # dictionary of room interface
        self.room_options = {
            0: self.help_list,
            1: self.roomItem,
            2: self.directionList,
        }


    # sets the players input into a command. EX "GO" "NORTH"
    def _set_command_pair(self, action, noun):
        self.current_command_pair = [action, noun]


    # returns the room item
    def _get_roomItem(self):
        return self.roomItem


    # returns the room directions
    def _get_directionList(self):
        return self.directionList


    # prints the tutorial
    def _get_help(self):
        print()
        for key, values in self.help_list["HELP"].items():
            print("{}: {}".format(key, values))
        print()
        input("Hit the ENTER key to continue")


    # room interface that is the main room loop allowing the player to interact with the room and move between rooms
    def room_interface(self, player, room):
        # updates UI and possible interactions to current room
        self._update_current_room_status(room)
        print("\nYou have entered the {}" .format(room.STATE_NAME))
        # used skip over printing the room item if there is no room item. allows affects input allowed to be entered
        offset = 1
        # default value used to be tested against in while loop
        iteration = "ENTERED"
        while iteration != "LEAVING":

            # used to print the player's Heads up Display
            player._get_player_status()

            # prints the room's command determined by room item status
            print("\n**ROOM COMMANDS**")
            if room.roomItem_has_item:
                self._get_room_option(offset)

            offset += 1
            self._get_room_option(offset)

            # takes the players input for room interaction and checks for valid input
            # If player enters a GO Direction command, current room is updated to new room
            if self._get_command() and self.process_command(player, room):
                iteration = "LEAVING"
            # if the player enters Quit, the game is exited to main menu
            elif self.QUIT:
                self.current_room = "GAME OVER"
                iteration = "LEAVING"
            # if the player interacts with an object instead of leaving, the loop restarts
            else:
                iteration = "LOOPING"
                offset -= 1
                self._update_current_room_status(room)

        return self.current_room


    # prints the possible room options such exit directions, collecting items, or unlocking items
    def _get_room_option(self, selection_index):
        for index, option in self.room_options.items():
            if index == selection_index:
                for key, value in option.items():
                    print("{}: ".format(key), end=" ")
                    for keys, values in value.items():
                        if values:
                            print("'{} : {}'".format(keys, values), end="    ")
        print()


    # takes the players input and checks for valid input
    def _get_command(self):
        valid = None
        while not valid:
            user_input = input().upper()

            # prints the tutorial for the player
            if user_input == "HELP":
                self._get_help()
                valid = False
            # exits the game back to main menu
            elif user_input == "QUIT":
                self.QUIT = True
                break
            # splits the userinput phrase into two words, make sure they are valid combination, then returns the command pair
            elif self.split_phrase(user_input) and self.check_for_valid_command(self.current_command_action,self.current_command_noun):
                self._set_command_pair(self.current_command_action, self.current_command_noun)
                valid = True
            else:
                print("Invalid Command!")
                valid = False
        return True


    # tries to split the user's input phrase into exactly two words.
    def split_phrase(self, phrase):
        try:
            player_command = phrase.split(" ")
            command_action = player_command[0]
            command_noun = player_command[1]
            self.current_command_action = command_action
            self.current_command_noun = command_noun
            return True

        except IndexError:
            print("INVALID PHRASE")
            return False


    # makes sure the command entered is a valid combination
    def check_for_valid_command(self, action, noun):
        for key, value in self.room_options.items():
            for keys, values in value.items():
                if action == keys:  # checks to see if action is a valid command
                    for index, commands in values.items():
                        if noun == index and commands != False:  # checks to see if command_value is a valid action
                            return True
        return False


    # process the valid command
    def process_command(self, player, room):
        action = self.current_command_action
        noun = self.current_command_noun

        # changes the room to the corresponding movement direction
        if action == "GO":
            self.current_room = self.directionList["GO"][noun]
            return True

        # collects the item or password, removes from room, adds to players inventory
        elif action == "COLLECT":
            if self.roomItem["COLLECT"]["ITEM"] == "PASSWORD":
                password = room._get_password()
                player._update_password(password)
            player._update_inventory(self.roomItem["COLLECT"]["ITEM"])
            room._update_roomItem()

        # interacts with locked object
        elif action == "INTERACT":
            self.roomItem = room.open_lock(player)

        # unlock locked door
        elif action == "UNLOCK":
            self.roomItem = room.open_door(player)

        return False




