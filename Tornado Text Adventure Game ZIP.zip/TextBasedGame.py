"""
MAIN FILE

Philip C. Smith 

Text Adventure Game 

02/19/2023

IT-140 Intro to Scripting

Zoe Likoudis





STORY: ESCAPE FROM TORNADO
-NEED TO FIND FIRST AID KIT
-NEED TO FIND PASSWORD TO ENTER SAFE ROOM
-FIND ALL ITEMS AND ENTER BEFORE TORNADO STRIKES HOUSE


*COMPLETED: (more or less)
-Main operating STATES: MENU, RUNNING, GAME OVER
-Basic Character creation
-Functional Game loop:
    -ROOM STATES fully implemented.
    -can go through all rooms
    -rooms are properly linked
    -player loses health each time they move from room to room
    -only lose health if don't have first aid kit
    -able to die
    -entering south SAFE ROOM that is outside ends the game successfully
    -be able to win if all items collected or lose without all items or fail to make inside safe room in time
    -able to collect all items
-basic UI has been implemented.
-uppercase all input for gameloop
-Admin mode to bypass character creation
-Decoupled character creation menu from Main Menu State for scalability
-Implemented dictionary of dictionary for commands to allow objects to pass dictionaries to other objects
-created a room manager to decouple rooms from functions that interact between rooms.
-implement locks and key checks
-able to quit during run time
-added a tornado timer

"""


import Controller

"""
CONTROLLER STATES:
-MENU: this is the main menu and character creation menus:
-RUNNING: the controller goes idle in this state while the GameLoop STATES are running.
-QUIT: Breaks out of the controller loop and ends the program.
"""
# creates an object from Controller class to act as a system controller.
controller = Controller.Controller()

# this while loop acts like turning the game and is the interface between the menus and the actual gameplay.
# checks the current state of the program, then enters that state. If the state is "QUIT" the system will close
while controller.get_GAME_STATE() != "QUIT":

    current_state = controller.get_GAME_STATE()

    for key, value in controller.GAME_STATES.items():
        if current_state == key:
            controller.set_GAME_STATE(value())

print("Game Successfully Closed!")
    

