from random import *
from datetime import datetime
"""
class that handles room attributes and room functions
"""

class Rooms:
    # default room attributes
    def __init__(self,
                 room_name="MASTER", state_name="MASTER",
                 room_item_type="ITEM", item="NO ITEM",
                 key=None, reward=None,
                 dirNorth=False, dirSouth=False, dirEast=False, dirWest=False,
                 item_flag=True
                 ):

        self.name = room_name
        self.STATE_NAME = state_name
        self.item_type = room_item_type
        self.item_name = item
        self.roomItem = {"COLLECT":
            {self.item_type: self.item_name}}
        self.roomItem_has_item = item_flag
        # stores roomItem so it can be placed behind a lock
        # setting it equal to self.roomItem causes it be overriden later
        self.unlocked_item = {"COLLECT":
            {self.item_type: self.item_name}}

        # possible room directions
        self.direction_north = dirNorth
        self.direction_south = dirSouth
        self.direction_east = dirEast
        self.direction_west = dirWest

        # dictionary of room directions
        self.directionList = {"GO": {
            "NORTH": self.direction_north,
            "SOUTH": self.direction_south,
            "EAST": self.direction_east,
            "WEST": self.direction_west}}

        # room locks, barriers, and items
        self.key_required = key
        self.locked_barrier = None
        self.reward_item = reward


    # returns the room name
    def _get_name(self):
        return self.name


    # returns the ROOM
    def _get_STATE_NAME(self):
        return self.STATE_NAME


    # returns the room item
    def _get_roomItem(self):
        return self.roomItem


    # returns if room has item or not
    def _get_roomItem_has_item(self):
        return self.roomItem_has_item


    # returns the directions to leave current room
    def _get_directionList(self):
        return self.directionList


    # updates the room to show the item has been collected
    def _update_roomItem(self):
        self.roomItem["ITEM"] = "NO ITEM"
        self.roomItem_has_item = False


    # removes locked item and replaces it with item inside so player can collect
    def _update_lock_status(self):
        self.roomItem = self.reward_item


    # creates a password for locked item
    def create_password(self):
        self.password = []
        seed(datetime.now().timestamp())
        for nums in range(3):
            value = randint(0, 100)
            self.password.append(value)


    # returns the password for locked item
    def _get_password(self):
        return self.password


    # prints the password for locked item
    def _print_password(self):
        for nums in self.password:
            print(nums, end=" ")
        print()


    # when room is created, creates the locked item, lock type, and item behind lock
    def _set_item_locks(self, item_name, key_required):
        self.key_required = key_required
        self.locked_barrier = item_name
        # overrides room item with lock
        self.roomItem = {"INTERACT": {self.locked_barrier: "LOCKED"}}


    # removes the locked item and replaces it with unlocked door so player can collect
    def open_lock(self, player):
        if self.key_required in player.inventory:
            print("You unlocked the {}".format(self.locked_barrier))
            self.roomItem = self.unlocked_item
        else:
            print("The {} is locked! Search the house to find something to unlock it".format(self.locked_barrier))
        return self.roomItem


    # when room is created, generates locked door, key required, and the direction exit locked
    def _set_door_locks(self, door_name, key_reqired, door_direction):
        self.locked_barrier = door_name # name of lock
        self.key_required = key_reqired # key required to unlock lock
        self.locked_door = door_direction # key direction of the door
        self.locked_item = self.directionList["GO"][door_direction] # saves original door to be unlocked
        self.directionList["GO"][door_direction] = None # sets the direction to None while locked
        self.roomItem = {"UNLOCK": {self.locked_barrier: self.locked_door}} # creates interface to unlock door


    # removes the locked barrier and replaces it room direction
    def open_door(self, player):
        if self.key_required == player.password:
            print("You unlocked the {}".format(self.locked_barrier))
            self.directionList["GO"][self.locked_door] = self.locked_item
            self._update_roomItem()

        else:
            print("This {} is locked! Quick, find someting to unlock it!".format(self.locked_barrier))

        return self.roomItem