import MainMenu
import GameLoop
import Player

"""
This class servers as a system controller and acts as a interface Between the 3 main system states: 
- Game Menu, 
- Running, 
- Quit
"""
class Controller:

    def __init__(self):
        # default state on boot up is "MENU"
        self.GAME_STATE = "MENU"
        # Dictionary of the system states
        self.GAME_STATES = {
            "MENU": self.state_GAME_MENU,
            "RUNNING": self.state_RUNNING,
            "QUIT": self.state_QUIT
        }
        # creates object of MainMenu class to create the Main Menu interface
        self.menu = MainMenu.MainMenu()

    # sets the system state
    def set_GAME_STATE(self, game_state):
        self.GAME_STATE = game_state

    # gets the system state
    def get_GAME_STATE(self):
        return self.GAME_STATE

    # runs the Main Menu state
    def state_GAME_MENU(self):
        new_state = self.menu.state_GAME_MENU()
        return new_state

    """ENTER GAME LOOP HERE"""

    # takes values from inputs entered during a new game and stores the values into a dictionary to be passed into the game
    def state_RUNNING(self):
        title = self.menu.player_attributes[1]
        first_name = self.menu.player_attributes[2]
        last_name = self.menu.player_attributes[3]
        pet_type = self.menu.player_attributes[4]
        pet_name = self.menu.player_attributes[5]
        player_attributes = {
                            1: title,
                            2: first_name,
                            3: last_name,
                            4: pet_type,
                            5: pet_name
                            }
        # passes the player attributes to the player
        player = Player.Player(player_attributes)
        # creates the game and passes the player into the gameloop
        game = GameLoop.GameLoop(player)
        # starts the game in the game loop
        return game.game_loop()


    # closes the program
    def state_QUIT(self):
        # debugging print state to follow control flow on shutdown
        print("QUITTING GAME")
        return "QUIT"
